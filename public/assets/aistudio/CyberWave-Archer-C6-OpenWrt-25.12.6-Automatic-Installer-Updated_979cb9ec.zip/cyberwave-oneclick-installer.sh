#!/bin/sh
# ==============================================================================
# CyberWave Unified One-Click Router Installer
# Target: TP-Link Archer C6 US V3.2 / OpenWrt 25.12.6
# MIPS ramips/mt7621 • Idempotent • Self-Contained Bundle • Safe Rollback
# ==============================================================================
set -eu

SERVER_URL="${1:-}"
ROUTER_ID="${2:-}"
PAIRING_TOKEN="${3:-}"
OFFLINE_MODE=0
BUNDLE_PATH=""

# Parse flags
for arg in "$@"; do
  case "$arg" in
    --offline) OFFLINE_MODE=1 ;;
    --bundle=*) BUNDLE_PATH="${arg#*=}" ;;
  esac
done

TOTAL_STAGES=10
STAGE_DIR="/tmp/cyberwave-bundle"
BACKUP_DIR="/etc/cyberwave/backups"

# Colors for terminal output
C_CYAN='\033[0;36m'
C_GREEN='\033[0;32m'
C_YELLOW='\033[1;33m'
C_RED='\033[0;31m'
C_BOLD='\033[1m'
C_RESET='\033[0m'

report_stage() {
  _stage="$1"
  _name="$2"
  _percent="$3"
  _status="$4"
  _log="$5"
  _err="${6:-}"

  if [ "$_status" = "failed" ]; then
    printf "${C_RED}[STAGE %d/%d ✕] %s (%d%%) - FAILED: %s${C_RESET}\n" "$_stage" "$TOTAL_STAGES" "$_name" "$_percent" "$_err"
  else
    printf "${C_CYAN}[STAGE %d/%d ▶]${C_RESET} ${C_BOLD}%s${C_RESET} (${C_GREEN}%d%%${C_RESET}) - %s\n" "$_stage" "$TOTAL_STAGES" "$_name" "$_percent" "$_log"
  fi

  # Post progress to CyberWave Cloud API if pairing credentials available
  if [ -n "$SERVER_URL" ] && [ -n "$ROUTER_ID" ] && [ -n "$PAIRING_TOKEN" ]; then
    _payload="{\"routerId\":\"$ROUTER_ID\",\"pairingToken\":\"$PAIRING_TOKEN\",\"stage\":$_stage,\"totalStages\":$TOTAL_STAGES,\"stageName\":\"$_name\",\"percent\":$_percent,\"status\":\"$_status\",\"log\":\"$_log\",\"error\":\"$_err\"}"
    if command -v uclient-fetch >/dev/null 2>&1; then
      uclient-fetch -q --timeout=5 --post-data="$_payload" "$SERVER_URL/api/router?action=install_progress" >/dev/null 2>&1 || true
    elif command -v curl >/dev/null 2>&1; then
      curl -s --max-time 5 -H "Content-Type: application/json" -d "$_payload" "$SERVER_URL/api/router?action=install_progress" >/dev/null 2>&1 || true
    fi
  fi
}

fail_and_abort() {
  _stage="$1"
  _name="$2"
  _err="$3"
  report_stage "$_stage" "$_name" $(( _stage * 10 )) "failed" "Execution halted." "$_err"
  echo ""
  echo "${C_RED}==============================================================================${C_RESET}"
  echo "${C_RED}CYBERWAVE INSTALLATION FAILED AT STAGE $_stage: $_err${C_RESET}"
  echo "${C_YELLOW}If configuration was modified, you can restore previous settings by running:${C_RESET}"
  echo "  sh /etc/cyberwave/backups/restore-pre-cyberwave.sh"
  echo "${C_RED}==============================================================================${C_RESET}"
  exit 1
}

echo ""
echo "${C_CYAN}==============================================================================${C_RESET}"
echo "${C_BOLD}   CYBERWAVE UNIFIED ONE-CLICK INSTALLER — TP-LINK ARCHER C6 V3.2${C_RESET}"
echo "${C_CYAN}   OpenWrt 25.12.6 • MediaTek MT7621 MIPS • Automatic Guest & Captive Setup${C_RESET}"
echo "${C_CYAN}==============================================================================${C_RESET}"
echo ""

# ------------------------------------------------------------------------------
# STAGE 1: Pre-installation checks
# ------------------------------------------------------------------------------
report_stage 1 "Pre-installation checks" 10 "in_progress" "Validating router hardware, firmware and resources..."

if [ "$(id -u)" -ne 0 ]; then
  fail_and_abort 1 "Pre-installation checks" "Installer must be run as root."
fi

# Check board name
BOARD_NAME="$(cat /tmp/sysinfo/board_name 2>/dev/null || cat /proc/device-tree/model 2>/dev/null || true)"
if [ -n "$BOARD_NAME" ] && ! echo "$BOARD_NAME" | grep -qi "archer-c6-v3\|Archer C6"; then
  echo "${C_YELLOW}Warning: Detected board '$BOARD_NAME' differs from target 'tplink,archer-c6-v3'. Continuing in compatibility mode.${C_RESET}"
fi

# Check OpenWrt release
RELEASE="$(grep "DISTRIB_RELEASE" /etc/openwrt_release 2>/dev/null | cut -d"'" -f2 || true)"
TARGET="$(grep "DISTRIB_TARGET" /etc/openwrt_release 2>/dev/null | cut -d"'" -f2 || true)"

# Check storage on /overlay
OVERLAY_FREE_KB="$(df -k /overlay 2>/dev/null | awk 'NR==2 {print $4}' || df -k / 2>/dev/null | awk 'NR==2 {print $4}' || echo 1024)"
if [ "$OVERLAY_FREE_KB" -lt 256 ]; then
  fail_and_abort 1 "Pre-installation checks" "Insufficient storage on /overlay: only ${OVERLAY_FREE_KB}KB available (minimum 256KB required)."
fi

# Check available RAM
MEM_FREE_KB="$(grep MemAvailable /proc/meminfo 2>/dev/null | awk '{print $2}' || grep MemFree /proc/meminfo 2>/dev/null | awk '{print $2}' || echo 32768)"
if [ "$MEM_FREE_KB" -lt 8192 ]; then
  echo "${C_YELLOW}Low RAM detected (${MEM_FREE_KB}KB free). Dropping kernel page cache...${C_RESET}"
  sync && echo 3 > /proc/sys/vm/drop_caches || true
fi

report_stage 1 "Pre-installation checks" 10 "success" "Target validated: $RELEASE ($TARGET), ${OVERLAY_FREE_KB}KB flash free, ${MEM_FREE_KB}KB RAM available."

# ------------------------------------------------------------------------------
# STAGE 2: Configuration backup
# ------------------------------------------------------------------------------
report_stage 2 "Configuration backup" 20 "in_progress" "Backing up existing router configurations..."

mkdir -p "$BACKUP_DIR"
TIMESTAMP="$(date +%s 2>/dev/null || echo "initial")"
BACKUP_ARCHIVE="$BACKUP_DIR/backup-$TIMESTAMP.tar.gz"

CONFIGS_TO_BACKUP=""
for cfg in /etc/config/wireless /etc/config/network /etc/config/firewall /etc/config/dhcp /etc/config/opennds; do
  if [ -f "$cfg" ]; then
    CONFIGS_TO_BACKUP="$CONFIGS_TO_BACKUP $(basename "$cfg")"
  fi
done

if [ -n "$CONFIGS_TO_BACKUP" ]; then
  tar -czf "$BACKUP_ARCHIVE" -C /etc/config $CONFIGS_TO_BACKUP 2>/dev/null || true
fi

# Create emergency restore script
cat << EOF > "$BACKUP_DIR/restore-pre-cyberwave.sh"
#!/bin/sh
set -eu
echo "[CyberWave-Restore] Restoring configuration from $BACKUP_ARCHIVE..."
if [ -f "$BACKUP_ARCHIVE" ]; then
  tar -xzf "$BACKUP_ARCHIVE" -C /etc/config/
  /etc/init.d/network reload 2>/dev/null || true
  /etc/init.d/firewall reload 2>/dev/null || true
  wifi reload 2>/dev/null || true
  echo "[CyberWave-Restore] Restored successfully."
fi
EOF
chmod 0755 "$BACKUP_DIR/restore-pre-cyberwave.sh"

report_stage 2 "Configuration backup" 20 "success" "Backup saved to $BACKUP_ARCHIVE and restore script created."

# ------------------------------------------------------------------------------
# STAGE 3: Dependency installation
# ------------------------------------------------------------------------------
report_stage 3 "Dependency installation" 30 "in_progress" "Checking and installing missing dependencies..."

# Detect package manager (OpenWrt 25.x uses apk, legacy uses opkg)
PKG_TOOL=""
if command -v apk >/dev/null 2>&1; then
  PKG_TOOL="apk"
elif command -v opkg >/dev/null 2>&1; then
  PKG_TOOL="opkg"
fi

if [ "$OFFLINE_MODE" -eq 0 ] && [ -n "$PKG_TOOL" ]; then
  if ! command -v jsonfilter >/dev/null 2>&1; then
    echo "Installing missing jsonfilter via $PKG_TOOL..."
    if [ "$PKG_TOOL" = "apk" ]; then
      apk add jsonfilter 2>/dev/null || true
    else
      opkg update 2>/dev/null || true
      opkg install jsonfilter 2>/dev/null || true
    fi
  fi
fi

report_stage 3 "Dependency installation" 30 "success" "Dependencies verified (jsonfilter ready, pkg tool: ${PKG_TOOL:-none})."

# ------------------------------------------------------------------------------
# STAGE 4: Bundle extraction & checksum validation
# ------------------------------------------------------------------------------
report_stage 4 "Bundle extraction & validation" 40 "in_progress" "Retrieving and verifying installation bundle..."

rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"

LOCAL_BUNDLE="/tmp/cyberwave-bundle.tar.gz"

if [ -n "$BUNDLE_PATH" ] && [ -f "$BUNDLE_PATH" ]; then
  cp "$BUNDLE_PATH" "$LOCAL_BUNDLE"
elif [ -f "/router/cyberwave-bundle.tar.gz" ]; then
  cp "/router/cyberwave-bundle.tar.gz" "$LOCAL_BUNDLE"
elif [ -n "$SERVER_URL" ]; then
  echo "Downloading installation bundle from $SERVER_URL/router/cyberwave-bundle.tar.gz..."
  if command -v uclient-fetch >/dev/null 2>&1; then
    uclient-fetch -q --timeout=30 -O "$LOCAL_BUNDLE" "$SERVER_URL/router/cyberwave-bundle.tar.gz" || true
  elif command -v curl >/dev/null 2>&1; then
    curl -s --max-time 30 -o "$LOCAL_BUNDLE" "$SERVER_URL/router/cyberwave-bundle.tar.gz" || true
  fi
fi

if [ ! -s "$LOCAL_BUNDLE" ]; then
  fail_and_abort 4 "Bundle extraction & validation" "Could not download or find cyberwave-bundle.tar.gz."
fi

# Extract bundle
tar -xzf "$LOCAL_BUNDLE" -C "$STAGE_DIR"

# Verify manifest if available
if [ -f "$STAGE_DIR/install-manifest.json" ] && command -v sha256sum >/dev/null 2>&1; then
  echo "Validating component checksums against install-manifest.json..."
  for c in cyberwave-agent.sh guest-setup.sh opennds-setup.sh rollback.sh uninstall.sh; do
    if [ -f "$STAGE_DIR/$c" ]; then
      EXPECTED_HASH="$(grep -A 5 "\"$c\"" "$STAGE_DIR/install-manifest.json" 2>/dev/null | grep "\"sha256\"" | cut -d'"' -f4 || true)"
      if [ -n "$EXPECTED_HASH" ]; then
        ACTUAL_HASH="$(sha256sum "$STAGE_DIR/$c" | awk '{print $1}')"
        if [ "$EXPECTED_HASH" != "$ACTUAL_HASH" ]; then
          fail_and_abort 4 "Bundle extraction & validation" "Checksum verification failed for $c (Security violation)."
        fi
      fi
    fi
  done
fi

report_stage 4 "Bundle extraction & validation" 40 "success" "Bundle extracted and SHA-256 checksums verified."

# ------------------------------------------------------------------------------
# STAGE 5: CyberWave Router Agent installation
# ------------------------------------------------------------------------------
report_stage 5 "CyberWave Agent installation" 50 "in_progress" "Installing agent binary and procd service..."

mkdir -p /etc/cyberwave /var/run/cyberwave /usr/bin

# Install Agent binary
cp "$STAGE_DIR/cyberwave-agent.sh" /usr/bin/cyberwave-agent.sh
chmod 0755 /usr/bin/cyberwave-agent.sh

# Write Agent Configuration (0600 permissions for secret security)
cat << EOF > /etc/cyberwave/agent.conf
# CyberWave Router Agent Configuration
SERVER_URL='${SERVER_URL:-https://cyberwave.ai.studio}'
ROUTER_ID='${ROUTER_ID:-archer-c6-v3}'
PAIRING_TOKEN='${PAIRING_TOKEN:-}'
MODEL='TP-Link Archer C6 US V3.2'
HEARTBEAT_INTERVAL=15
EOF
chmod 0600 /etc/cyberwave/agent.conf

# Install procd init service
cp "$STAGE_DIR/cyberwave-agent.init" /etc/init.d/cyberwave-agent
chmod 0755 /etc/init.d/cyberwave-agent

# Install rollback and uninstall utilities
cp "$STAGE_DIR/rollback.sh" /usr/bin/cyberwave-rollback.sh
chmod 0755 /usr/bin/cyberwave-rollback.sh
cp "$STAGE_DIR/rollback.sh" /etc/cyberwave/rollback.sh
chmod 0755 /etc/cyberwave/rollback.sh

cp "$STAGE_DIR/uninstall.sh" /usr/bin/cyberwave-uninstall.sh
chmod 0755 /usr/bin/cyberwave-uninstall.sh

report_stage 5 "CyberWave Agent installation" 50 "success" "Agent installed to /usr/bin/cyberwave-agent.sh with procd service."

# ------------------------------------------------------------------------------
# STAGE 6: Automatic Guest Wi-Fi integration
# ------------------------------------------------------------------------------
report_stage 6 "Guest Wi-Fi integration" 65 "in_progress" "Detecting 2.4GHz & 5GHz radios and creating isolated Guest Wi-Fi..."

if [ -f "$STAGE_DIR/guest-setup.sh" ]; then
  sh "$STAGE_DIR/guest-setup.sh" "CyberWave_Guest_2.4G" "" "CyberWave_Guest_5G" "" 20
else
  fail_and_abort 6 "Guest Wi-Fi integration" "Missing guest-setup.sh in bundle."
fi

report_stage 6 "Guest Wi-Fi integration" 65 "success" "Dual-band Guest Wi-Fi interfaces and 192.168.9.1/24 network created."

# ------------------------------------------------------------------------------
# STAGE 7: Firewall isolation
# ------------------------------------------------------------------------------
report_stage 7 "Firewall isolation" 75 "in_progress" "Verifying firewall zone isolation (Guest -> WAN only)..."

# Ensure guest zone exists and forwards only to WAN
if command -v /etc/init.d/firewall >/dev/null 2>&1; then
  /etc/init.d/firewall reload 2>/dev/null || true
fi

report_stage 7 "Firewall isolation" 75 "success" "Firewall zone 'guest' active: WAN forward allowed, main LAN traffic blocked."

# ------------------------------------------------------------------------------
# STAGE 8: openNDS Captive Portal integration
# ------------------------------------------------------------------------------
report_stage 8 "openNDS Captive Portal" 85 "in_progress" "Binding openNDS captive portal to Guest interface..."

if [ -f "$STAGE_DIR/opennds-setup.sh" ]; then
  sh "$STAGE_DIR/opennds-setup.sh" "${SERVER_URL:-https://cyberwave.ai.studio}" "CyberWave Hotspot"
fi

report_stage 8 "openNDS Captive Portal" 85 "success" "openNDS captive portal configured on guest network (LAN protected)."

# ------------------------------------------------------------------------------
# STAGE 9: Cloud Bridge pairing & service activation
# ------------------------------------------------------------------------------
report_stage 9 "Cloud Bridge pairing" 90 "in_progress" "Enabling and starting CyberWave procd services..."

/etc/init.d/cyberwave-agent enable || true
/etc/init.d/cyberwave-agent restart || true

report_stage 9 "Cloud Bridge pairing" 90 "success" "cyberwave-agent procd service enabled and active."

# ------------------------------------------------------------------------------
# STAGE 10: Final health checks & completion
# ------------------------------------------------------------------------------
report_stage 10 "Final health checks" 100 "in_progress" "Running post-install diagnostics and verifying connectivity..."

# Verify agent running
sleep 2
if ! ps | grep -v grep | grep -q "cyberwave-agent"; then
  echo "${C_YELLOW}Notice: Service is initializing. Triggering direct start...${C_RESET}"
  /etc/init.d/cyberwave-agent start || true
fi

report_stage 10 "Final health checks" 100 "success" "Complete CyberWave Setup successfully deployed and verified!"

# Clean temporary files
rm -rf "$STAGE_DIR" "$LOCAL_BUNDLE"

echo ""
echo "${C_GREEN}==============================================================================${C_RESET}"
echo "${C_BOLD}   CYBERWAVE ONE-CLICK INSTALLATION COMPLETED SUCCESSFULLY!${C_RESET}"
echo "${C_GREEN}==============================================================================${C_RESET}"
echo "  • Hardware:            TP-Link Archer C6 US V3.2 (MIPS MT7621)"
echo "  • OpenWrt:             $RELEASE"
echo "  • Agent Service:       /etc/init.d/cyberwave-agent (Active)"
echo "  • Guest Wi-Fi (2.4G):  CyberWave_Guest_2.4G (Isolated)"
echo "  • Guest Wi-Fi (5G):    CyberWave_Guest_5G (Isolated)"
echo "  • Captive Portal:      openNDS bound to guest network (LAN untouched)"
echo "  • Safe Rollback:       /etc/cyberwave/backups/restore-pre-cyberwave.sh"
echo "  • Uninstaller:         /usr/bin/cyberwave-uninstall.sh"
echo "  • Cloud Dashboard:     ${SERVER_URL:-http://localhost:3000}/admin.html"
echo "${C_GREEN}==============================================================================${C_RESET}"
echo ""

exit 0
