# CyberWave — Router Management System & OpenWrt Automatic Secure Bridge

**Cloud Platform:** Google AI Studio (`http://localhost:3000`) & Vercel Production  
**Router Target:** TP-Link Archer C6 US V3.2 (`tplink,archer-c6-v3`)  
**Firmware Target:** OpenWrt `25.12.6` · `ramips/mt7621` · MIPS architecture · APK package manager  
**Designer:** **DESIGN BY SAMIM MANDAL**

CyberWave হলো TP-Link Archer C6 V3.2 রাউটার এবং OpenWrt 25.12.6 ফার্মওয়্যারের জন্য একটি সম্পূর্ণ লাইটওয়েট রাউটার ম্যানেজমেন্ট ড্যাশবোর্ড ও ক্লাউড ব্রিজ সিস্টেম। এটি Google AI Studio এবং ক্লাউড হোস্টিং উভয় পরিবেশেই নিরবচ্ছিন্নভাবে চলে।

---

## 1. প্রজেক্টের প্রধান ফিচার ও আর্কিটেকচার

CyberWave Google AI Studio তে সরাসরি Express সার্ভার দিয়ে চলে এবং আপস্ট্যাশ রেডিস ছাড়াও স্থানীয় ডিস্ক পারসিস্টেন্স (`data/`) ফলব্যাক সমর্থন করে।

- **Real-Time Router Telemetry:** CPU load, RAM usage, 16MB Flash overlay storage, WAN/LAN rx/tx bytes ও লাইভ আপলোড/ডাউনলোড স্পিড।
- **Dual-Band Main Wi-Fi:** 2.4 GHz ও 5 GHz রেডিও চ্যানেল, ট্রান্সমিট পাওয়ার ও সিকিউরিটি কনফিগারেশন।
- **Dual-Band Guest Wi-Fi:** সম্পূর্ণ আলাদা ও আইসোলেটেড 2.4 GHz ও 5 GHz গেস্ট নেটওয়ার্ক, পাসওয়ার্ড প্রোটেকশন, এবং ক্লায়েন্ট লিমিট কন্ট্রোল।
- **Connected Clients & Access Control:** প্রতিটি কানেক্টেড ক্লায়েন্টের আইপি, ম্যাক, সিগন্যাল (dBm), ব্যান্ড (2.4G/5G) এবং লাইভ Kick ও Block/Unblock সুবিধা।
- **openNDS Captive Portal Engine:** openNDS সার্ভিস টগল, এফএএস (FAS) অথেন্টিকেশন, এবং অটোমেটিক রিডাইরেক্ট।
- **Guest Voucher Management:** কাস্টম প্রিফিক্স সহ ব্যাচ ভাউচার তৈরি, ম্যাক বাইন্ডিং, কিউআর কোড জেনারেশন, এবং CSV/JSON এক্সপোর্ট।
- **System Diagnostics & Kernel Logs:** রিমোট `dmesg`, `logread`, `ping_test` এবং ড্রপ ক্যাশ (Free RAM) অপারেশন।
- **10-Step Automatic Installer:** Archer C6 V3.2 এর জন্য অপ্টিমাইজড, যাতে ইনস্টলেশনের আগে সম্পূর্ণ UCI ব্যাকআপ `/etc/cyberwave/backups/`-এ সংরক্ষিত হয়।
- **Non-Destructive Safe Rollback:** ওয়ান-ক্লিক আনইনস্টলার যা রাউটার ফ্যাক্টরি রিসেট না করেই পূর্ববর্তী অবস্থায় ফিরিয়ে দেয়।

- Admin Dashboard: Router pairing, status, audit/command view।
- Cloud API: pairing, heartbeat, telemetry, command queue ও result confirmation।
- Upstash Redis: Router profile, heartbeat status ও pending command-এর persistent storage।
- OpenWrt Agent: telemetry পাঠায়, অনুমোদিত command গ্রহণ করে এবং result ফেরত পাঠায়।
- Captive Portal API: openNDS portal, request, voucher এবং Telegram integration-এর server-side endpoints।

### Bridge-এর যোগাযোগ

```text
CyberWave Admin (Vercel)
          |
          | Admin-authenticated pairing / one-time installer ticket
          v
CyberWave Router API  <---->  Upstash Redis
          ^
          |
          | Outbound HTTPS heartbeat + command result
          |
Archer C6 V3.2 — CyberWave Agent
          |
          +-- ubus / UCI / DHCP lease / openNDS status
```

Router থেকে Public Internet-এ SSH, LuCI বা RPC port খুলতে হয় না। Agent outbound HTTPS ব্যবহার করে।

## 2. সমর্থিত Router ও প্রয়োজনীয় শর্ত

| বিষয় | প্রয়োজনীয় মান |
|---|---|
| Router | TP-Link Archer C6 V3.2 |
| Board name | `tplink,archer-c6-v3` |
| OpenWrt | `25.12.6` |
| Target | `ramips/mt7621` |
| Package manager | `apk` |
| HTTPS client | `uclient-fetch` |
| Services | `rpcd`, `uhttpd` init scripts থাকতে হবে |
| Free overlay | কমপক্ষে 256 KB |
| Cloud | `https://cyberwave.ai.studio` |
| Persistence | Upstash Redis REST API |

এই Installer অন্য Archer revision, অন্য board বা অন্য OpenWrt release-এ জোর করে চালানো যাবে না। Installer mismatch পেলে থেমে যাবে।

### Archer C6-এ আগে থেকে যাচাই

Router-এ SSH করে চালান:

```sh
cat /etc/openwrt_release
cat /tmp/sysinfo/board_name
apk --version
command -v uclient-fetch
/etc/init.d/rpcd status
/etc/init.d/uhttpd status
df -h
```

Expected values:

```text
DISTRIB_RELEASE='25.12.6'
DISTRIB_TARGET='ramips/mt7621'
tplink,archer-c6-v3
apk-tools 3.x
```

যদি package index refresh প্রয়োজন হয়:

```sh
apk update
```

`curl` ইনস্টল করা বাধ্যতামূলক নয়। Agent/Installer `uclient-fetch` ব্যবহার করে।

---

## 3. Vercel ও GitHub Deployment

### 3.1 GitHub Repository প্রস্তুত করুন

1. ZIP Extract করুন।
2. Extract করা Project-এর ভেতরের সব ফাইল ও folder Repository Root-এ রাখুন।
3. `api/`, `lib/`, `public/`, `router/`, `docs/`, `test/`, `package.json`, `vercel.json` এবং `README.md` একই project root-এ আছে কি না দেখুন।
4. `.env` বা কোনো ব্যক্তিগত Secret GitHub-এ Push করবেন না। শুধু `.env.example` রাখা যাবে।
5. GitHub-এ Commit ও Push করুন।

### 3.2 Vercel Project

1. Vercel-এ Login করুন।
2. **Add New → Project** নির্বাচন করুন।
3. আপনার CyberWave GitHub Repository Import করুন।
4. Root Directory হিসেবে Repository Root রাখুন; `api` বা `public` subfolder নির্বাচন করবেন না।
5. Project-এর Environment Variables সেট করুন (Section 4)।
6. Deploy করুন।
7. Custom Domain হিসেবে `cyberwave.ai.studio` যুক্ত ও Verify করুন।
8. Deploy সম্পন্ন হলে Domain-এর HTTPS কাজ করছে কি না নিশ্চিত করুন।

**যদি আপনার বর্তমান Vercel Project ইতিমধ্যে ঠিকভাবে Deploy হয়:** অকারণে Framework Preset, Build Command বা Output Directory পরিবর্তন করবেন না। Existing working deployment configuration বজায় রেখে নতুন commit deploy করুন। `package.json`-এর `build` script বর্তমানে JavaScript syntax check করে; এটি Vite frontend bundle তৈরির script নয়।

### 3.3 Deployment-এর পর প্রাথমিক পরীক্ষা

Browser-এ খুলুন:

- `https://cyberwave.ai.studio`
- `https://cyberwave.ai.studio/admin.html`
- `https://cyberwave.ai.studio/api/config`

`/api/config`-এ Redis configure না থাকলে বা server error এলে প্রথমে Environment Variables এবং Vercel Function Logs পরীক্ষা করুন। Admin Dashboard-এ প্রবেশ করতে Section 4-এ দেওয়া `ADMIN_PASSWORD` ব্যবহার করুন।

---

## 4. Vercel Environment Variables

Vercel → Project → **Settings → Environment Variables**-এ প্রয়োজনীয় Variable যোগ করুন। Production deployment-এর জন্য Production environment নির্বাচন করুন। Preview ব্যবহার করলে প্রয়োজনমতো Preview-তেও আলাদা value দিন।

| Variable | প্রয়োজন | ব্যবহার |
|---|---|---|
| `ADMIN_PASSWORD` | আবশ্যক | Admin Dashboard login |
| `UPSTASH_REDIS_REST_URL` | আবশ্যক | Redis REST endpoint |
| `UPSTASH_REDIS_REST_TOKEN` | আবশ্যক | Redis authentication |
| `ROUTER_SECRET_KEY` | জোরালোভাবে সুপারিশকৃত | Legacy router/poll ও shared API authentication |
| `TELEGRAM_BOT_TOKEN` | Telegram ব্যবহার করলে | Telegram Bot API |
| `TELEGRAM_CHAT_ID` | Telegram ব্যবহার করলে | Admin notification chat/group |
| `TIMEZONE` | ঐচ্ছিক | Timestamp formatting; যেমন `Asia/Kolkata` |
| `ARCHER_C6_SECRET` | ঐচ্ছিক/Legacy | পুরোনো Archer API secret |

### 4.1 Admin Password

একটি শক্তিশালী, আলাদা Password ব্যবহার করুন। `ADMIN_PASSWORD`-কে Router pairing token বা Upstash token-এর সঙ্গে একই রাখবেন না।

### 4.2 Upstash Redis তৈরি

1. `https://console.upstash.com/` খুলুন।
2. Redis database তৈরি করুন।
3. Database-এর REST API section থেকে URL ও Token নিন।
4. Vercel-এ যথাক্রমে `UPSTASH_REDIS_REST_URL` ও `UPSTASH_REDIS_REST_TOKEN` যোগ করুন।

Router Bridge pairing, one-time installer ticket, heartbeat persistence ও command queue-এর জন্য Redis প্রয়োজন। শুধু Vercel Function memory-র ওপর নির্ভর করবেন না—serverless instance স্থায়ী নয়।

### 4.3 Router Secret তৈরি

নিজের কম্পিউটারে OpenSSL থাকলে:

```sh
openssl rand -hex 32
```

উৎপন্ন value `ROUTER_SECRET_KEY` হিসেবে Vercel-এ রাখুন। এটি কাউকে পাঠাবেন না।

**Bridge Agent-এর pairing credential আলাদা:** Admin Dashboard থেকে Router Pair করার সময় per-router token তৈরি হয়। Installer সেটি নিরাপদে Router-এর `/etc/cyberwave/agent.conf`-এ রাখে। Agent-এর জন্য `ROUTER_SECRET_KEY` হাতে কপি করে Router-এ বসাতে হয় না।

### 4.4 Environment Variable পরিবর্তনের পর

Vercel Environment Variables পরিবর্তন করলে নতুন Deployment করতে হবে। শুধু Save করলেই ইতিমধ্যে Deploy হওয়া Function-এ পরিবর্তন কার্যকর হয় না।

---

## 5. Admin Dashboard থেকে Router Pairing

1. `https://cyberwave.ai.studio/admin.html` খুলুন।
2. `ADMIN_PASSWORD` দিয়ে Login করুন।
3. **Remote OpenWrt Router Bridge** section খুঁজুন।
4. **Regenerate Pairing Token** চাপুন।
5. Confirm করুন। নতুন Token তৈরি হলে আগের Agent-এর credential আর কাজ করবে না; আগে থেকে paired Router থাকলে সেটিকে নতুন Installer দিয়ে পুনরায় Install করতে হবে।
6. **Copy SSH 1-Line Installer** অথবা **Copy Code** চাপুন।
7. Dashboard একটি one-time Installer Ticket তৈরি করে এবং SSH command Clipboard-এ Copy করে।
8. Ticket সর্বোচ্চ 5 মিনিট বৈধ এবং একবার ব্যবহারযোগ্য। Expire বা consume হয়ে গেলে নতুন command Copy করুন।

> **নিরাপত্তা:** Installer command-এ অল্প সময়ের জন্য ব্যবহারযোগ্য ticket থাকে। Pairing token, Installer command বা `/etc/cyberwave/agent.conf`-এর content Public chat, screenshot বা GitHub-এ দেবেন না।

---

## 6. Archer C6 V3.2-এ Automatic Installation

### 6.1 SSH-তে Router-এ প্রবেশ

আপনার কম্পিউটার/ফোন Router-এর LAN বা Wi-Fi-তে যুক্ত রেখে SSH client খুলুন:

```sh
ssh root@192.168.1.1
```

নিজের Router LAN IP আলাদা হলে সেটি ব্যবহার করুন। Password চাইলে OpenWrt root password দিন।

### 6.2 Installer command চালানো

1. SSH session-এ `root@OpenWrt:~#` prompt দেখা যাচ্ছে কি না নিশ্চিত করুন।
2. CyberWave Admin Dashboard থেকে Copy করা **সম্পূর্ণ এক লাইনের command** Paste করুন।
3. Enter চাপুন।
4. Installer-এর Preflight ও Download শেষ হওয়া পর্যন্ত অপেক্ষা করুন।

Command-এর URL-এ `ticket=` অংশ থাকবে। নিজে হাতে URL বা token সম্পাদনা করবেন না।

### 6.3 Installer কী কী পরীক্ষা/কাজ করে

Installer:

1. Root privilege পরীক্ষা করে।
2. OpenWrt release file পরীক্ষা করে।
3. Board name `tplink,archer-c6-v3` যাচাই করে।
4. Release `25.12.6` ও target `ramips/mt7621` যাচাই করে।
5. `uclient-fetch`, `rpcd`, `uhttpd` এবং Overlay free space পরীক্ষা করে।
6. HTTPS দিয়ে Agent ও Uninstaller download করে।
7. Download করা shell script-এর `sh -n` syntax validation করে।
8. `jsonfilter` না থাকলে APK দিয়ে সেটি যোগ করার চেষ্টা করে।
9. `/etc/cyberwave/agent.conf` তৈরি করে এবং Secret file permission `0600` করে।
10. `/etc/init.d/cyberwave-agent` procd service তৈরি করে, Enable ও Start করে।

Installer `apk upgrade` চালায় না। `curl`, Node.js বা Android package ইনস্টল করে না। Firewall/WAN/LAN/Wi-Fi configuration পরিবর্তন করে না এবং LuCI/RPC-কে WAN-এ প্রকাশ করে না।

### 6.4 Router-এ তৈরি হওয়া ফাইল

| Path | কাজ |
|---|---|
| `/usr/bin/cyberwave-agent.sh` | Bridge Agent |
| `/usr/bin/cyberwave-uninstall.sh` | Uninstaller |
| `/etc/cyberwave/agent.conf` | Server URL, Router ID ও pairing secret |
| `/etc/init.d/cyberwave-agent` | procd service |
| `/var/log/cyberwave-agent.log` | Agent log |
| `/var/run/cyberwave/` | Runtime state ও processed command IDs |

`/etc/cyberwave/agent.conf` private credential ধারণ করে। এটি অন্য কারও সঙ্গে Share করবেন না।

---

## 7. Installation Verify করা

Router SSH-তে:

```sh
/etc/init.d/cyberwave-agent status
```

Service log:

```sh
logread -e cyberwave-agent
```

Agent-এর নিজস্ব log:

```sh
tail -n 50 /var/log/cyberwave-agent.log
```

Storage:

```sh
df -h
```

Service startup configuration:

```sh
ls -l /etc/init.d/cyberwave-agent
ls -l /etc/cyberwave/agent.conf
```

Agent সাধারণত 15 সেকেন্ড পরপর heartbeat পাঠায়। Dashboard-এ **Refresh Status** চাপুন। সফল authentication ও Redis persistence থাকলে Router Online দেখাতে হবে। Backend-এর Online status সর্বশেষ heartbeat 45 সেকেন্ডের মধ্যে এলে Online হিসেবে গণ্য হয়।

### Agent কী Telemetry পাঠায়

বর্তমান Agent-এর telemetry-তে থাকতে পারে:

- Router model, OpenWrt version, uptime, load ও memory।
- WAN IP, gateway, DNS, protocol ও connection state।
- 2.4 GHz/5 GHz SSID, channel, transmit power, encryption ও enabled state।
- `/tmp/dhcp.leases` থেকে DHCP lease-এর MAC, IP ও hostname।
- openNDS process চলছে কি না এবং `ndsctl` থেকে authorized client count (যদি openNDS ইনস্টল থাকে)।

এই তথ্য Cloud API হয়ে Upstash Redis-এ সংরক্ষিত হয়। SSID/Network তথ্য ও client MAC/IP ব্যক্তিগত নেটওয়ার্ক তথ্য—এই Cloud telemetry আপনার ব্যবহারের জন্য গ্রহণযোগ্য কি না বিবেচনা করুন। Agent Wi-Fi password telemetry-তে পাঠায় না।

---

## 8. বর্তমানে সমর্থিত Remote Command

API ও Agent-এর বর্তমান Bridge allowlist:

| Action | কাজ | শর্ত/নোট |
|---|---|---|
| `ping_test` | নির্দিষ্ট Host ping | Target hostname/IP sanitize করা হয় |
| `drop_caches` | Linux page cache drop | Router-এর RAM cache প্রভাবিত হয় |
| `wifi_reload` | Wireless reload | সাময়িক Wi-Fi disconnect হতে পারে |
| `backup_config` | UCI configuration backup | `/tmp/cyberwave-uci-backup.tar.gz` |
| `set_wifi_ssid` | নির্দিষ্ট radio SSID পরিবর্তন | Agent-এর interface allowlist মেনে চলে |
| `nds_auth` | openNDS client authorize | openNDS/`ndsctl` ইনস্টল থাকতে হবে |
| `nds_deauth` | openNDS client deauthorize | openNDS/`ndsctl` ইনস্টল থাকতে হবে |
| `reboot` | Router reboot | সংযোগ সাময়িক বিচ্ছিন্ন হবে |

সব Dashboard Action এই Bridge Agent-এ সমর্থিত নয়। API unsupported action হলে queue-তে পাঠানোর বদলে প্রত্যাখ্যান করে। Unsupported action-কে জোর করে চালানোর চেষ্টা করবেন না।

---

## 9. openNDS Captive Portal আলাদাভাবে সেটআপ করতে হবে

Automatic Bridge Installer openNDS ইনস্টল করে না। Router-এ openNDS আছে কি না পরীক্ষা করুন:

```sh
command -v opennds
/etc/init.d/opennds status
```

যদি `not found` বা init script missing আসে, openNDS এখনো ইনস্টল নেই। তখন আপনার exact OpenWrt release-এর compatible package, FAS version এবং Captive Portal network design যাচাই করে আলাদা করে সেটআপ করতে হবে।

openNDS ছাড়া Bridge-এর সাধারণ heartbeat ও system telemetry চলতে পারে; কিন্তু `nds_auth`, `nds_deauth` এবং Captive Portal authorization flow কাজ করবে না।

**সতর্কতা:** যাচাই না করে `/etc/config/opennds`-এ পুরোনো FAS configuration paste করবেন না। FAS security level, key, interface ও portal URL আপনার installed openNDS version-এর সঙ্গে মিলতে হবে।

---

## 10. Troubleshooting

### A. `Installer ticket expired or invalid`

- Ticket 5 মিনিটের মধ্যে expire হয়।
- Ticket একবারই ব্যবহার করা যায়।
- Admin Dashboard-এ ফিরে আবার **Copy Code** চাপুন।
- নতুন command SSH-তে চালান।

### B. `Unsupported board` বা `Expected OpenWrt 25.12.6`

চালান:

```sh
cat /tmp/sysinfo/board_name
cat /etc/openwrt_release
```

Board, release বা target মেলেনি। অন্য firmware বা device-এ এই installer চালাবেন না।

### C. `uclient-fetch is required`

```sh
command -v uclient-fetch
```

না থাকলে Installer থেমে যাবে। Router-এর উপযুক্ত OpenWrt repository ও firmware package availability যাচাই করে তবেই package যোগ করুন।

### D. HTTPS download/TLS error

```sh
date
apk info | grep ca-bundle
```

তারিখ ভুল হলে NTP/time sync ঠিক করুন। CA bundle অনুপস্থিত হলে package repository refresh করে প্রয়োজনীয় certificate package ইনস্টল করতে হবে। TLS verification বন্ধ করে বা HTTP URL ব্যবহার করে সমস্যা পাশ কাটাবেন না।

### E. `jsonfilter` ইনস্টল করতে ব্যর্থ

```sh
command -v jsonfilter
apk update
apk add jsonfilter
```

তারপর Dashboard থেকে নতুন Installer command তৈরি করে আবার চালান। Package install-এর আগে `df -h` দিয়ে free overlay পরীক্ষা করুন।

### F. Dashboard-এ Router Offline

```sh
logread -e cyberwave-agent
tail -n 50 /var/log/cyberwave-agent.log
```

তারপর যাচাই করুন:

- Router-এর Internet ও DNS কাজ করছে কি না।
- Vercel Deployment সফল কি না।
- Upstash URL/Token সঠিক কি না।
- Admin থেকে Router pairing করা হয়েছে কি না।
- Pairing token regenerate করার পর পুরোনো Agent রয়ে গেছে কি না।
- Router-এর সময় সঠিক কি না।

### G. `401 Unauthorized`

Admin-এ নতুন Pairing Token তৈরি হলে পুরোনো Agent secret revoke হয়ে যায়। নতুন Installer command তৈরি করে Router-এ পুনরায় install করুন। পুরোনো `agent.conf` manually copy করে রাখবেন না।

### H. `503 Router Bridge requires configured Upstash Redis persistence`

Vercel Environment Variables-এ `UPSTASH_REDIS_REST_URL` ও `UPSTASH_REDIS_REST_TOKEN` আছে কি না দেখুন। পরিবর্তন করলে নতুন Deployment করুন।

---

## 11. Agent Uninstall

Router SSH-তে চালান:

```sh
/usr/bin/cyberwave-uninstall.sh
```

এটি:

- Agent service stop করে।
- Service disable করে।
- `/etc/init.d/cyberwave-agent` সরায়।
- `/usr/bin/cyberwave-agent.sh` সরায়।
- `/etc/cyberwave/agent.conf` সরায়।

Uninstaller বিদ্যমান LAN/WAN/Wi-Fi/firewall configuration পরিবর্তন করে না। Uninstaller script নিজে `/usr/bin/cyberwave-uninstall.sh`-এ থেকে যেতে পারে; চাইলে সফল uninstall-এর পরে আলাদাভাবে সরাতে পারেন:

```sh
rm -f /usr/bin/cyberwave-uninstall.sh
```

Cloud Admin Dashboard-এ Router unpair/revoke করার অপশন থাকলে সেটিও ব্যবহার করুন। শুধু Router থেকে Agent সরালে Cloud-এর paired profile নিজে থেকে delete নাও হতে পারে।

---

## 12. Security Checklist

- [ ] `ADMIN_PASSWORD` শক্তিশালী ও unique।
- [ ] Upstash Redis REST Token গোপন রাখা হয়েছে।
- [ ] `ROUTER_SECRET_KEY` আলাদা random value।
- [ ] `.env` GitHub-এ Push করা হয়নি।
- [ ] Pairing token/Installer command Public-এ Share করা হয়নি।
- [ ] LuCI, rpcd বা SSH WAN-এ expose করা হয়নি।
- [ ] Router-এর firmware ও package source সঠিক release/target-এর।
- [ ] Router Admin password default রাখা হয়নি।
- [ ] Vercel ও Upstash account-এ MFA ব্যবহার করা হয়েছে, যদি উপলব্ধ থাকে।

---

## 13. Repository Structure

```text
.
├── api/                    # Vercel Serverless API endpoints
├── lib/                    # Redis, Admin, Telegram ও Router bridge logic
│   └── router/
├── public/
│   ├── admin.html          # Web Admin Dashboard
│   ├── index.html          # Captive Portal page
│   └── router/
│       ├── install-agent.sh
│       ├── cyberwave-agent.sh
│       └── cyberwave-uninstall.sh
├── router/                 # OpenWrt scripts ও service definitions
├── docs/
│   ├── OPENWRT-25.12.6-AUTOMATIC-INSTALL.md
│   └── specifications/
├── test/                   # Automated tests
├── .env.example            # Placeholder environment template
├── package.json
├── vercel.json
└── README.md
```

---

## 14. Test Commands (Developer)

Node.js environment-এ dependencies install করে:

```sh
npm ci
npm test
```

Shell syntax check:

```sh
sh -n router/install-agent.sh
sh -n router/cyberwave-agent.sh
sh -n router/cyberwave-uninstall.sh
sh -n public/router/install-agent.sh
sh -n public/router/cyberwave-agent.sh
```

Tests পাস করলেও বাস্তব Router/Vercel/Upstash deployment-এ pairing ও heartbeat পরীক্ষা করতে হবে। Unit test বাস্তব hardware integration-এর বিকল্প নয়।

---

## 15. License

MIT License. বিস্তারিত `LICENSE` ফাইলে দেখুন।
